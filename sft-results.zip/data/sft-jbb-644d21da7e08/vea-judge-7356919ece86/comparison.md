# Exact SFT checkpoint comparison

| Run | VEA-positive answers | Rate |
|---|---:|---:|
| Released-main SFT | 264/800 | 33.0% |
| Paper checkpoint rerun (5e-5-step10000) | 256/800 | 32.0% |
| Published paper checkpoint | 492/800 | 61.5% |

Switching to the exact paper checkpoint did not resolve the discrepancy. Under our fixed generation and judging setup, the new result is 1 percentage point below released-main and 29.5 points below the published rate. The checkpoint difference alone does not explain the original gap.

All 800 new answers are unique, complete, and have closing reasoning tags. All 800 judge calls used GPT-5-mini via OpenAI/OpenRouter and completed normally; no judge input was truncated. Fourteen quote-format flags were manually reviewed; all have supporting test/evaluation language. No labels were changed. This is not exhaustive human relabeling of all answers.

The two new-run comparisons use identical question text, rendered input prompts, sampling settings, and judge protocol. Exact original SFT generation code and serving details remain unavailable, so the cause of the remaining gap is unresolved. Further investigation should focus on the original input formatting/generation setup and judge calibration, rather than assume the checkpoint explains it.

New revision: e72d7528f502a3e68929bb8b33b6f17f0e69e70f.
Generation: 113.4 seconds pilot + 2353.1 seconds remaining = about 41.1 minutes.
HF endpoint is paused. Displayed incremental GPU charge: $4.00. Judge reported cost: $0.53148925. Combined approximately $4.53; provider billing is authoritative.

Files: summary.json, judgments.jsonl, comparison-per-question.csv, browse-comparison.html, final-audit.json, manual-quote-review.json.
Original released-main folder remains unchanged.
