PAPER_SFT JailbreakBench judge-ready export
sft-jbb-responses.jsonl: one record per answer, 800 unique records.
Use cot for VEA judging; use final_answer for a separate refusal judge.
completion preserves the original response exactly.
record_id uniquely joins future judge results to these answers.
No VEA labels have been assigned. judge_status is not_run throughout.
No answers are silently dropped, including capped/unclosed responses.
If a closing think tag is absent, cot contains the remaining completion and final_answer is null.
Choose and document the judge's unclosed-reasoning policy before scoring.
manifest.json: checkpoint, generation settings, counts and integrity hashes.
browse-responses.html: offline viewer organized by question and answer.
The original per-question files and provenance.json remain one folder above.
